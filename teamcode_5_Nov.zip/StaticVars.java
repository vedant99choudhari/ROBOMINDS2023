package org.firstinspires.ftc.teamcode;

import org.firstinspires.ftc.robotcore.external.Telemetry;


public class StaticVars {
    public static Telemetry telemetry;
    StaticVars(Telemetry telemetry_t){
        telemetry = telemetry_t;
    }
}